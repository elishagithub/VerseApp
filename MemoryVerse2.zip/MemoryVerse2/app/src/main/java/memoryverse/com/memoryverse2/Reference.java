package memoryverse.com.memoryverse2;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import memoryverse.com.memoryverse2.model.AllVerse;
import memoryverse.com.memoryverse2.model.Verse;
import memoryverse.com.memoryverse2.rest.RestClient;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class Reference extends Activity {

    ArrayList<Verse> verses;
    ReferenceAdapter adapter;
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reference_main);
        mProgressDialog = new ProgressDialog(Reference.this);
        mProgressDialog.setMessage("Currently downloading...");
        mProgressDialog.setIndeterminate(false);
        mProgressDialog.setMax(100);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        Log.i("Main", "finito onCreate");

        verses = new ArrayList<Verse>();

        getVerses();

        ListView listview = (ListView) findViewById(R.id.list);
        adapter = new ReferenceAdapter(getApplicationContext(),
                R.layout.reference_row, verses);

        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long id) {
                Verse verse = verses.get(position);
                String verse_id = String.valueOf(verse.getId());
                Intent i = new Intent(getApplicationContext(), ReferenceDetailPage.class);
                i.putExtra("id", verse_id);
                startActivity(i);
            }
        });
    }
    public void getVerses(){
        final ProgressDialog dialog;
        dialog = new ProgressDialog(Reference.this);
        dialog.setMessage("Loading, please wait");
        dialog.setTitle("Connecting server");
        dialog.show();
        dialog.setCancelable(false);
        List<Verse> versesFromSugar = Verse.listAll(Verse.class);
       if (versesFromSugar.size() == 0){
           RestClient.getRouteService().getVerses(new Callback<AllVerse>() {
               @Override
               public void success(AllVerse allVerse, Response response) {
                   ArrayList<Verse> versesFromRemote =  allVerse.getVerse();
                   verses.addAll(versesFromRemote);
                   Verse.deleteAll(Verse.class);
                   Verse.saveInTx(versesFromRemote);
                   adapter.notifyDataSetChanged();
                   dialog.dismiss();
               }
               @Override
               public void failure(RetrofitError error) {
                   Toast.makeText(Reference.this,"Error",Toast.LENGTH_LONG);
                   dialog.dismiss();
               }
           });
       }else{
           verses.addAll(versesFromSugar);
           dialog.dismiss();
       }
    }
}
