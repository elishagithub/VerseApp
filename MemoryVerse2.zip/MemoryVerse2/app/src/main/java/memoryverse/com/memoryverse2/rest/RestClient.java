package memoryverse.com.memoryverse2.rest;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import memoryverse.com.memoryverse2.rest.service.RouteService;
import retrofit.RestAdapter;
import retrofit.converter.GsonConverter;

public class RestClient {

    private static RouteService routeService;
    private static SessionRequestInterceptor sessionInterceptor;




    private static String  lat = null;
    private static String  lon = null;
    private static String base_url ="https://www.googleapis.com";
    public static void init(String token) {
        Gson gson = new GsonBuilder().create();
        sessionInterceptor = new SessionRequestInterceptor();


        RestAdapter restAdapter = new RestAdapter.Builder()
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setEndpoint(base_url)
                .setConverter(new GsonConverter(gson))
                .setRequestInterceptor(sessionInterceptor)
                .build();
        routeService = restAdapter.create(RouteService.class);
    }

    public static void setAuth_token(String token){
        sessionInterceptor.setAuthToken(token);

    }
    public static void setLocation(String lat,String lon){
        RestClient.lat = lat;
        RestClient.lon = lon;
        sessionInterceptor.setLatLon(lat, lon);
    }

    public static String getLat() {
        return lat;
    }
    public static String getLon() {
        return lon;
    }

    public static RouteService getRouteService() {

        return routeService;
    }

}
