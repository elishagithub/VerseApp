package memoryverse.com.memoryverse2.model;

import com.orm.SugarRecord;

public class Verse  extends SugarRecord<Verse> {
    String chapter;
    String type;
    String text;
    String date;

    public String getChapter() {
        return chapter;
    }

    public void setChapter(String chapter) {
        this.chapter = chapter;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
