package memoryverse.com.memoryverse2.rest.service;



import java.util.ArrayList;

import memoryverse.com.memoryverse2.model.AllVerse;
import retrofit.Callback;
import retrofit.http.GET;


public interface RouteService {
    @GET("/fusiontables/v2/query?sql=SELECT%20*%20FROM%20182q8Sxc-H_CWfyFG6YK4A6Niq-BgVYUgZJMrruUk&key=AIzaSyCxOuJYAPIHFjy1aH6Oz9XlrOEPnz08fAw")
    public void getVerses(Callback<AllVerse> callback);
}
