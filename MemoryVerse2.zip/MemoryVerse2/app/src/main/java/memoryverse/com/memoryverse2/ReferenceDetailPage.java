package memoryverse.com.memoryverse2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import memoryverse.com.memoryverse2.model.Verse;

public class ReferenceDetailPage extends Activity {
	TextView article, verseText;
	Button rightButton, wrongButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.articledetailpage);
		article = (TextView) findViewById(R.id.articleTV);
		verseText = (TextView) findViewById(R.id.verseText);

		rightButton = (Button)findViewById(R.id.correct);
		wrongButton = (Button)findViewById(R.id.wrong);

        Intent i = getIntent();
        long id = Long.valueOf(i.getExtras().getString("id"));
        Verse v =  Verse.findById(Verse.class,id);
        article.setText(v.getChapter());
		final String a = v.getText();

		rightButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				verseText.setText(a);
			}
		});

		wrongButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				verseText.setText(a);

			}
		});



	}
}
