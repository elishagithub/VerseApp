package memoryverse.com.memoryverse2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import memoryverse.com.memoryverse2.model.Verse;

public class ArticlesAdapter extends ArrayAdapter<Verse> {
	ArrayList<Verse> verses;
	LayoutInflater vi;
	int Resource;
	ViewHolder holder;

	public ArticlesAdapter(Context context, int resource,
			ArrayList<Verse> objects) {
		
		super(context, resource, objects);
		
		vi = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		Resource = resource;
		verses = objects;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// convert view = design
		View v = convertView;
		if (v == null) {
			holder = new ViewHolder();
			v = vi.inflate(Resource, null);

			holder.tvName = (TextView) v.findViewById(R.id.tvName);
			holder.tvHeight = (TextView) v.findViewById(R.id.tvHeight);
            holder.tvBody = (TextView) v.findViewById(R.id.tvBody);
			holder.tvDOB = (TextView) v.findViewById(R.id.tvDateOfBirth);

			v.setTag(holder);

		} else {
			holder = (ViewHolder) v.getTag();
		}

        Verse verse = verses.get(position);
		holder.tvName.setText(verse.getChapter());
		holder.tvHeight.setText(verse.getType());
		holder.tvBody.setText(verse.getText());
		holder.tvDOB.setText(verse.getText());

		return v;

	}

	static class ViewHolder {

		public TextView tvName;
		public TextView tvHeight;
		public TextView tvBody;
		public TextView tvDOB;

	}
}