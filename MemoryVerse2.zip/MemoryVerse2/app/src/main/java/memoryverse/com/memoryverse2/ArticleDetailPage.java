package memoryverse.com.memoryverse2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.TextView;

import memoryverse.com.memoryverse2.model.Verse;

public class ArticleDetailPage extends Activity {
	TextView article;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.articledetailpage);
		article = (TextView) findViewById(R.id.articleTV);

        Intent i = getIntent();
        long id = Long.valueOf(i.getExtras().getString("id"));
        Verse v =  Verse.findById(Verse.class,id);
        article.setText(v.getText());

	}
}
