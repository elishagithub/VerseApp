package memoryverse.com.memoryverse2.model;

import com.orm.SugarRecord;

import java.util.ArrayList;

public class AllVerse{
    ArrayList<ArrayList<String>> rows;

    public ArrayList<ArrayList<String>> getRows() {
        return rows;
    }

    public void setRows(ArrayList<ArrayList<String>> rows) {
        this.rows = rows;
    }

    public ArrayList<Verse> getVerse(){
        ArrayList<Verse> verses = new ArrayList<Verse>();
        int i;
        int total = getRows().size();
        for(i=0;i<total; i++){
           ArrayList<String> array = getRows().get(i);
            Verse v = new Verse();
            v.setChapter(array.get(0));
            v.setType(array.get(1));
            v.setText(array.get(2));
            v.setDate(array.get(3));
            verses.add(v);
        }
        return verses;
    }
}
