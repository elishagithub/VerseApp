package memoryverse.com.memoryverse2;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import memoryverse.com.memoryverse2.model.AllVerse;
import memoryverse.com.memoryverse2.model.Verse;
import memoryverse.com.memoryverse2.rest.RestClient;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class Articles extends Activity {

    ArrayList<Verse> verses;
    ArticlesAdapter adapter;
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.articles_main);
        mProgressDialog = new ProgressDialog(Articles.this);
        mProgressDialog.setMessage("Currently downloading...");
        mProgressDialog.setIndeterminate(false);
        mProgressDialog.setMax(100);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        Log.i("Main", "finito onCreate");

        verses = new ArrayList<Verse>();

        getVerses();

        ListView listview = (ListView) findViewById(R.id.list);
        adapter = new ArticlesAdapter(getApplicationContext(),
                R.layout.articles_row, verses);

        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long id) {

                Intent i = new Intent(getApplicationContext(), SwipeViews.class);
                startActivity(i);

              /*  Verse verse = verses.get(position);
                String verse_id = String.valueOf(verse.getId());
                Intent i = new Intent(getApplicationContext(), ArticleDetailPage.class);
                i.putExtra("id", verse_id);
                startActivity(i);

                */

            }
        });
    }
    public void getVerses(){
        final ProgressDialog dialog;
        dialog = new ProgressDialog(Articles.this);
        dialog.setMessage("Loading, please wait");
        dialog.setTitle("Connecting server");
        dialog.show();
        dialog.setCancelable(false);
        List<Verse> versesFromSugar = Verse.listAll(Verse.class);
       if (versesFromSugar.size() == 0){
           RestClient.getRouteService().getVerses(new Callback<AllVerse>() {
               @Override
               public void success(AllVerse allVerse, Response response) {
                   ArrayList<Verse> versesFromRemote =  allVerse.getVerse();
                   verses.addAll(versesFromRemote);
                   Verse.deleteAll(Verse.class);
                   Verse.saveInTx(versesFromRemote);
                   adapter.notifyDataSetChanged();
                   dialog.dismiss();
               }
               @Override
               public void failure(RetrofitError error) {
                   Toast.makeText(Articles.this,"Error",Toast.LENGTH_LONG);
                   dialog.dismiss();
               }
           });
       }else{
           verses.addAll(versesFromSugar);
           dialog.dismiss();
       }
    }
}
